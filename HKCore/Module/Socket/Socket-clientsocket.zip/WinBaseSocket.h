#ifndef _WINBASESOCKET_H__
#define _WINBASESOCKET_H__

#include "../OSInterface/OSInterface.h"

#ifndef OS_QT_LINUX
#include <Winsock2.h>
#pragma comment( lib, "ws2_32.lib" )
#endif

const int ERR_MAXLENGTH=512;

class CWinBaseSocket
{
public:
	CWinBaseSocket();
	virtual ~CWinBaseSocket();

	static BOOL g_bInitFlag;	//��ʼ����־
	static BOOL InitSocket();
	static void ExitSocket();

public:
	virtual BOOL IsSocketClose();
	virtual void Attach(SOCKET hSocket);
	virtual BOOL Create(int nNetTYpe);
	virtual BOOL Close();
	virtual BOOL Bind(const char* strIP, unsigned int iPort );
	virtual BOOL get_LocalIP( char* strIP );	
	virtual BOOL get_LocalPort( int* iPort );	
	virtual BOOL get_RemoteIP( char* strIP );
	virtual BOOL get_RemotePort( int* iPort );	
	virtual BOOL get_RemoteIP_Port( char* strIP,   int* iPort);
	virtual BOOL get_LocalHost( char* strBuffer, int iBufLen );
	virtual BOOL get_RemoteHost( char* strBuffer, int iBufLen );
	virtual BOOL set_SendTimeout( int ms );
	virtual BOOL set_ReceiveTimeout( int ms );	
	virtual void longToDottedQuad( unsigned long ulLong, char* pBuffer );
	virtual BOOL GetInitFlag();
	virtual void  get_LastError( char* strBuffer, int* iErrNum );
	
	CString GetError(DWORD error);
	CString GetError();

public:	
	void set_LastError( char* newError, int errNum );

public:	
	sockaddr_in m_sockaddr;	
	sockaddr_in m_rsockaddr;	
	WORD m_wVersion;
	char m_LastError[ERR_MAXLENGTH+1];
	int	 m_ErrorNumber;

private:
	BOOL m_bAttachFlag;

public:	
	SOCKET m_hSocket;	
};

BOOL Socket_JoinLeaf(const char *pszMultIp, SOCKET &sk);//�����鲥
BOOL Socket_GetSubNetMask(const char *pszIP, BYTE &b1, BYTE &b2, BYTE &b3, BYTE &b4);//��ȡ��������
void Socket_InitSocketAddr(	struct sockaddr_in &skt, const char *pszIP, long nPort);
void Socket_GetBroadcastAddr(struct sockaddr_in &skt, const char *pszIP);

BOOL Socket_SetSocketKeepAlive(SOCKET sock, long keepalivetime=900, long keepaliveinterval=1000, bool onoff=TRUE);

#endif

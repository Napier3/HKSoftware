#ifndef  _WINTCPSOCKET_CLIENT_H__
#define  _WINTCPSOCKET_CLIENT_H__

#include "WinTcpSocket.h"

class CWinTcpSocketClient : public CWinTcpSocket
{
public:
	CWinTcpSocketClient();
	virtual ~CWinTcpSocketClient();

public:
	virtual BOOL Connect(const char* strRemote, unsigned int iPort );	
	virtual void Attach(SOCKET hSocket);
	virtual SOCKET Detatch();
	virtual void CreateRcvThread();
	virtual long OnReceive(BYTE *pRcvBuf, int iLen);
	virtual void OnSocketIdle(long nMs);
	virtual void OnClose(int nErrorCode);
	virtual BOOL InitSocketClient(int nMs);
	virtual BOOL Close();

	//lijq 2020-4-25  ���������߳�
	virtual void ExitRcvTrhead();

protected:
	static UINT TcpClientThread(LPVOID pParam);
	CWinThread *m_pThread;
	BOOL m_bExitTcpClientThread;
	BOOL m_bDetach; //�����Detatch�����ܷ���OnClose
};

#endif
#include "stdafx.h"
#include "WinTcpSocketClient.h"

CWinTcpSocketClient::CWinTcpSocketClient()
{
	m_pThread = NULL;
	m_dwReceiveGap = 1;
	m_bExitTcpClientThread = FALSE;
	m_bDetach = FALSE;
}

CWinTcpSocketClient::~CWinTcpSocketClient()
{
	Close();

	while(m_pThread != NULL)
	{
		Sleep(1);
	}
}

void CWinTcpSocketClient::Attach(SOCKET hSocket)
{
	CWinBaseSocket::Attach(hSocket);
}

SOCKET CWinTcpSocketClient::Detatch()
{
	m_bDetach = TRUE;
	SOCKET hSocket = m_hSocket;
	m_hSocket = NULL;
	return hSocket;
}


void CWinTcpSocketClient::CreateRcvThread()
{
	if (m_pThread == NULL)
	{
		m_pThread = AfxBeginThread(TcpClientThread, (LPVOID)this);
		//2020-04-06  lijq �߳̽���ʱ���Զ�ɾ���̶߳���
		m_pThread->m_bAutoDelete = TRUE;
	}
}

BOOL CWinTcpSocketClient::Connect(const char* strRemote, unsigned int iPort )
{
	BOOL bTrue = CWinTcpSocket::Connect(strRemote, iPort);

	if (!bTrue)
	{
		return FALSE;
	}

	m_pThread = AfxBeginThread(TcpClientThread, (LPVOID)this);
	//2020-04-06  lijq �߳̽���ʱ���Զ�ɾ���̶߳���
	m_pThread->m_bAutoDelete = TRUE;

	return TRUE;
}


BOOL CWinTcpSocketClient::InitSocketClient(int nMs)
{
	BOOL bRet1 = set_SendTimeout(nMs);

#ifdef _CLogPrint_h__
	if (!bRet1)
	{
		CLogPrint::LogString(XLOGLEVEL_TRACE, _T("���÷��ͳ�ʱʧ��"));
	}
#endif

	BOOL bRet2 = set_ReceiveTimeout( nMs );

#ifdef _CLogPrint_h__
	if (!bRet2)
	{
		CLogPrint::LogString(XLOGLEVEL_TRACE, _T("���ý��ܳ�ʱʧ��"));
	}
#endif

	return bRet1 && bRet2;
}

long CWinTcpSocketClient::OnReceive(BYTE *pRcvBuf, int iLen)
{
	TRACE("%s\r\n", (char*)pRcvBuf);
	return 0;
}

UINT CWinTcpSocketClient::TcpClientThread(LPVOID pData)
{
	InitSocket();

	int numrcv;
	CWinTcpSocketClient *pSocket = (CWinTcpSocketClient*)pData;
	SOCKET clientSocket = (SOCKET)pSocket->m_hSocket;
	char *buffer = (char*)pSocket->m_pReceiveBuff;
	DWORD dwReceiveBuffLen = pSocket->m_dwReceiveBuffLen;
	DWORD dwRcvGap = pSocket->m_dwReceiveGap;

	while (1)
	{
		if (pSocket->m_bExitTcpClientThread)
		{
			pSocket->m_bExitTcpClientThread = FALSE;
			break;
		}

		if (pSocket->m_bDetach)
		{
			break;
		}

		if (pSocket->m_hSocket == NULL)
		{
			break;
		}

		numrcv = recv(clientSocket, buffer, dwReceiveBuffLen, 0);

		if (numrcv == SOCKET_ERROR)
		{
			if (pSocket->IsSocketClose())
			{
				pSocket->CWinTcpSocket::Close();
			}

			Sleep(dwRcvGap);
			continue;
			//break;
		}

		if (numrcv == 0)
		{
			if (pSocket->IsSocketClose())
			{
				pSocket->CWinTcpSocket::Close();
				break;
			}

			pSocket->OnSocketIdle(dwRcvGap);
			Sleep(dwRcvGap);
			continue;
		}

		pSocket->OnReceive((BYTE*)buffer, numrcv);
	}

	pSocket->m_pThread = NULL;

	if (!pSocket->m_bDetach)
	{ //�����Detatch�����ܷ���OnClose
		pSocket->OnClose(0);
	}

	return 0;
}


void CWinTcpSocketClient::OnSocketIdle(long nMs)
{
	
}

void CWinTcpSocketClient::OnClose(int nErrorCode)
{
	
}

BOOL CWinTcpSocketClient::Close()
{
	return CWinTcpSocket::Close();
}

void CWinTcpSocketClient::ExitRcvTrhead()
{
	m_bExitTcpClientThread = TRUE;

	while (m_pThread != NULL)
	{
		Sleep(1);
	}
}
